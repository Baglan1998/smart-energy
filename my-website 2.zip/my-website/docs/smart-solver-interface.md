# Smart Solver 4.0 interface

The standalone interface is served from `smart-solver/index.html`. It consumes the shared modules
`network-model.js`, `ybus.js`, and `power-flow.js`; it does not contain a second power-flow solver.

## State separation

- Project records contain only normalized source data and SVG coordinates.
- The current power-flow result lives in memory and is cleared when electrical data changes.
- Comparison snapshots A/B are stored separately from projects and include the network structure
  signature used to prevent comparison of incompatible networks.
- Exported project JSON does not contain calculated results. Results use a separate CSV export.

## Compatibility

Imported canonical and legacy JSON is passed through `NetworkModel.normalizeNetwork()`.
An existing `smartEnergySettings.rastrMode` localStorage record is exposed in the project selector
as a compatible legacy source. Opening it never overwrites the Rastr Mode record.

## Transformer currents

`ratedCurrentFromA` and `ratedCurrentToA` are checked against `currentFromA` and `currentToA`
respectively. Legacy `ratedCurrentA` is treated as a from-side transformer rating. The interface never
compares both transformer terminal currents with one common passport value.

## SVG and charts

The single-line SVG and all charts read source data or the current `calculatePowerFlow()` result.
They determine only presentation properties such as positions, scale, and arrow direction; they do not
calculate voltages, currents, powers, or losses.
