'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const NetworkModel = require('../lib/network-model.js');
const { network220KV } = require('../examples/network-220kv.js');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function issueCodes(diagnostics) {
  return new Set([...diagnostics.errors, ...diagnostics.warnings].map((issue) => issue.code));
}

test('legacy-поля Rastr Mode переводятся в каноническую модель', () => {
  const normalized = NetworkModel.normalizeNetwork({
    name: 'Legacy', baseMVA: 100,
    nodes: [
      { id: 'h', name: 'ВН', type: 'slack', nominalKV: 220, setVoltageKV: 220, setAngleDeg: 0, loadMW: 0, loadMvar: 0, generationMW: null, generationMvar: null },
      { id: 'l', name: 'НН', type: 'load', nominalKV: 10, setVoltageKV: null, setAngleDeg: 0, loadMW: null, loadMvar: 0, generationMW: 0, generationMvar: 0 }
    ],
    branches: [
      { id: 't1', from: 'h', to: 'l', type: 'transformer', rOhm: 1, xOhm: 10, bMicroS: 0, ratio: 10 / 220, iMaxA: null }
    ]
  });

  assert.equal(normalized.basePowerMVA, 100);
  assert.equal(normalized.nodes[0].type, 'Slack');
  assert.equal(normalized.nodes[0].voltageSetpointPU, 1);
  assert.equal(normalized.nodes[1].type, 'PQ');
  assert.equal(normalized.nodes[1].loadPMW, null);
  assert.equal(normalized.branches[0].fromNodeId, 'h');
  assert.equal(normalized.branches[0].toNodeId, 'l');
  assert.equal(normalized.branches[0].tapRatio, 1);
  assert.equal(normalized.branches[0].phaseShiftDeg, 0);
  assert.equal(normalized.branches[0].ratedCurrentA, null);
  assert.equal(normalized.branches[0].ratedCurrentFromA, null);
  assert.equal(normalized.branches[0].ratedCurrentToA, null);
});

test('эталонная сеть 220 кВ проходит диагностику', () => {
  const diagnostics = NetworkModel.validateNetwork(network220KV);
  assert.equal(diagnostics.ok, true);
  assert.equal(diagnostics.errors.length, 0);
  assert.equal(diagnostics.islands.length, 1);
  assert.deepEqual(diagnostics.islands[0].nodeIds, ['bus-1', 'bus-2']);
});

test('диагностика находит ID, ссылки, self-loop и нулевой импеданс', () => {
  const network = clone(network220KV);
  network.nodes.push({ ...network.nodes[1], name: 'Дубль' });
  network.branches = [
    { ...network.branches[0], resistanceOhm: 0, reactanceOhm: 0, toNodeId: 'bus-1' },
    { ...network.branches[0], toNodeId: 'missing' }
  ];
  const codes = issueCodes(NetworkModel.validateNetwork(network));
  assert.equal(codes.has('duplicate_node_id'), true);
  assert.equal(codes.has('duplicate_branch_id'), true);
  assert.equal(codes.has('branch_self_loop'), true);
  assert.equal(codes.has('missing_branch_node'), true);
  assert.equal(codes.has('zero_branch_impedance'), true);
});

test('диагностика разделяет ошибки и предупреждения топологии', () => {
  const network = clone(network220KV);
  network.nodes.push({
    id: 'bus-3', name: 'Изолированный', type: 'PQ', nominalVoltageKV: 220,
    voltageSetpointPU: null, angleSetpointDeg: null, loadPMW: 0, loadQMvar: 0,
    generationPMW: 0, generationQMvar: 0, qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true
  });
  const diagnostics = NetworkModel.validateNetwork(network);
  const codes = issueCodes(diagnostics);
  assert.equal(diagnostics.ok, false);
  assert.equal(codes.has('isolated_node'), true);
  assert.equal(codes.has('multiple_islands'), true);
  assert.equal(codes.has('island_without_slack'), true);
  assert.equal(diagnostics.warnings.some((issue) => issue.code === 'isolated_node'), true);
});

test('несогласованные классы линии и неверный tap блокируют расчёт', () => {
  const lineNetwork = clone(network220KV);
  lineNetwork.nodes[1].nominalVoltageKV = 110;
  assert.equal(issueCodes(NetworkModel.validateNetwork(lineNetwork)).has('line_voltage_class_mismatch'), true);

  const transformerNetwork = clone(network220KV);
  transformerNetwork.branches[0].type = 'transformer';
  transformerNetwork.branches[0].tapRatio = 0;
  assert.equal(issueCodes(NetworkModel.validateNetwork(transformerNetwork)).has('invalid_tap_ratio'), true);
});

test('несколько Slack-узлов отклоняются текущим решателем', () => {
  const network = clone(network220KV);
  Object.assign(network.nodes[1], { type: 'Slack', voltageSetpointPU: 1, angleSetpointDeg: 0 });
  const codes = issueCodes(NetworkModel.validateNetwork(network));
  assert.equal(codes.has('multiple_slack_in_island'), true);
  assert.equal(codes.has('multiple_slack_nodes'), true);
});
