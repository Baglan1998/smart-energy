'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Calculations = require('../lib/calculations.js');

function closeTo(actual, expected, tolerance = 1e-9) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
}

test('эталон 220 кВ и 80 + j30 МВА: S, cosφ и трёхфазный ток', () => {
  const power = Calculations.calculateComplexPower({ activeMW: 80, reactiveMvar: 30 });
  closeTo(power.apparentMVA, Math.sqrt(80 ** 2 + 30 ** 2));
  closeTo(power.powerFactor, 80 / Math.sqrt(80 ** 2 + 30 ** 2));

  const currentA = Calculations.calculateThreePhaseCurrent({
    apparentMVA: power.apparentMVA,
    voltageKV: 220
  });
  closeTo(currentA, power.apparentMVA * 1e6 / (Math.sqrt(3) * 220e3));
  closeTo(currentA, 224.22194828710215, 1e-9);
});

test('формулы P и Q восстанавливают 80 МВт и 30 Мвар', () => {
  const apparentMVA = Calculations.apparentPower(80, 30);
  const currentA = Calculations.calculateThreePhaseCurrent({ apparentMVA, voltageKV: 220 });
  const cosPhi = Calculations.powerFactor(80, 30);
  const sinPhi = 30 / apparentMVA;

  closeTo(Calculations.calculateThreePhaseActivePower({ voltageKV: 220, currentA, powerFactor: cosPhi }), 80);
  closeTo(Calculations.calculateThreePhaseReactivePower({ voltageKV: 220, currentA, sinPhi }), 30);
});

test('удельные R0 и X0 переводятся в параметры линии', () => {
  const impedance = Calculations.calculateLineImpedance({
    lengthKM: 100,
    resistanceOhmPerKM: 0.08,
    reactanceOhmPerKM: 0.4
  });
  assert.deepEqual(impedance, { resistanceOhm: 8, reactanceOhm: 40 });
});

test('потери трёхфазной линии считаются по 3I²R и 3I²X', () => {
  const losses = Calculations.calculateThreePhaseLineLosses({
    currentA: 200,
    resistanceOhm: 2,
    reactanceOhm: 5
  });
  assert.equal(losses.activeLossW, 240000);
  assert.equal(losses.activeLossKW, 240);
  assert.equal(losses.reactiveLossVar, 600000);
  assert.equal(losses.reactiveLossKvar, 600);
});

test('однофазная и трёхфазная формулы не смешиваются', () => {
  const onePhase = Calculations.calculatePower({ network: 'one', voltage: 230, current: 10, powerFactor: 1 });
  const threePhase = Calculations.calculatePower({ network: 'three', voltage: 230, current: 10, powerFactor: 1 });
  closeTo(onePhase.activeKW, 2.3);
  closeTo(threePhase.activeKW, Math.sqrt(3) * 2.3);
});

test('некорректные исходные данные не превращаются в нули', () => {
  assert.throws(() => Calculations.calculateThreePhaseCurrent({ apparentMVA: 10, voltageKV: 0 }), RangeError);
  assert.throws(() => Calculations.calculateComplexPower({ activeMW: null, reactiveMvar: 30 }), TypeError);
  assert.throws(() => Calculations.calculateLineImpedance({ lengthKM: -1, resistanceOhmPerKM: 0.1, reactanceOhmPerKM: 0.4 }), RangeError);
  assert.throws(() => Calculations.calculatePower({ network: 'dc', voltage: 230, current: 10, powerFactor: 1 }), RangeError);
  assert.equal(Calculations.powerFactor(0, 0), null);
});

test('существующий расчёт ЛЭП использует то же ядро', () => {
  const result = Calculations.calculateTransmissionLine({
    voltageKV: 220,
    lengthKM: 100,
    activeMW: 80,
    reactiveMvar: 30,
    resistancePerKM: 0.08,
    reactancePerKM: 0.4
  });
  closeTo(result.apparentMVA, Math.sqrt(7300));
  closeTo(result.current, 224.22194828710215);
  assert.equal(result.resistance, 8);
  assert.equal(result.reactance, 40);
  closeTo(result.lossesKW, 3 * result.current ** 2 * result.resistance / 1000);
  closeTo(result.reactiveLossesKvar, 3 * result.current ** 2 * result.reactance / 1000);
});
