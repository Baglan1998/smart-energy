'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadBrowserKernel() {
  const context = { console, Date, Math, setTimeout, clearTimeout };
  context.window = context;
  context.globalThis = context;
  vm.createContext(context);
  ['complex.js', 'calculations.js', 'per-unit.js', 'network-model.js', 'ybus.js', 'power-flow.js'].forEach((file) => {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'lib', file), 'utf8'), context, { filename: file });
  });
  return context;
}

test('Rastr Mode legacy-сеть проходит через новые NetworkModel и Ybus', () => {
  const kernel = loadBrowserKernel();
  const network = {
    name: 'Legacy integration', baseMVA: 100,
    nodes: [
      { id: 'n1', number: 1, name: 'Источник', type: 'slack', nominalKV: 220, setVoltageKV: 220, setAngleDeg: 0, loadMW: 0, loadMvar: 0, generationMW: 0, generationMvar: 0, qMinMvar: null, qMaxMvar: null },
      { id: 'n2', number: 2, name: 'Нагрузка', type: 'load', nominalKV: 220, setVoltageKV: null, setAngleDeg: 0, loadMW: 80, loadMvar: 30, generationMW: 0, generationMvar: 0, qMinMvar: null, qMaxMvar: null }
    ],
    branches: [
      { id: 'b1', number: 1, name: 'Линия', from: 'n1', to: 'n2', type: 'line', rOhm: 11.8, xOhm: 40.5, bMicroS: 280, ratio: 1, iMaxA: 600, enabled: true },
      { id: 'b2', number: 2, name: 'Резерв', from: 'n1', to: 'n2', type: 'line', rOhm: 12, xOhm: 42, bMicroS: 250, ratio: 1, iMaxA: 500, enabled: false }
    ],
    settings: { tolerance: 1e-8, maxIterations: 30 }
  };

  const matrix = kernel.PowerFlow.buildYBus(network);
  const result = kernel.calculatePowerFlow(network);
  assert.equal(matrix.ok, true);
  assert.equal(result.converged, true);
  assert.equal(result.nodes.length, 2);
  assert.equal(result.branches.length, 2);
  assert.equal(result.branches.find((branch) => branch.id === 'b2').enabled, false);
  assert.equal(result.branches.find((branch) => branch.id === 'b2').loadingPercent, null);
});
