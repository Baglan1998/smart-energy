'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const PowerFlow = require('../lib/power-flow.js');
const { matpowerCase9 } = require('../examples/matpower-case9.js');

/*
 * Frozen reference values below were produced by an independent Python solver:
 * polar Newton iterations with a central finite-difference Jacobian and a
 * separately stamped complex Ybus. It imports no Smart Solver source.
 */
const REFERENCES = Object.freeze({
  network220: Object.freeze({
    voltage2PU: 0.9567573189431702,
    angle2Deg: -3.6639078113063506,
    slackPMW: 81.8553938359142,
    slackQMvar: 23.389443184722758
  }),
  threeBus: Object.freeze({
    voltage3PU: 1.022826637675444,
    angle2Deg: 0.09046891126974604,
    angle3Deg: -2.184158039925729,
    slackPMW: 25.846203061359213,
    slackQMvar: 31.54343416480589,
    pvQMvar: -12.17867972488978
  }),
  transformer: Object.freeze({
    voltageLowPU: 0.9959362478388065,
    angleLowDeg: -0.5580456073485243,
    activeLossMW: 0.01098913274846,
    reactiveLossMvar: 0.109891327484604
  })
});

function close(actual, expected, tolerance = 1e-7, message = '') {
  assert.ok(Number.isFinite(actual), `${message}: результат должен быть конечным`);
  assert.ok(Math.abs(actual - expected) <= tolerance, `${message}: ${actual} != ${expected} ± ${tolerance}`);
}

function node(id, type, nominalVoltageKV, values = {}) {
  return {
    id,
    name: values.name || `Узел ${id}`,
    type,
    nominalVoltageKV,
    voltageSetpointPU: type === 'Slack' || type === 'PV' ? values.voltage ?? 1 : null,
    angleSetpointDeg: type === 'Slack' ? values.angle ?? 0 : null,
    loadPMW: values.loadP ?? 0,
    loadQMvar: values.loadQ ?? 0,
    generationPMW: values.generationP ?? 0,
    generationQMvar: values.generationQ ?? 0,
    qMinMvar: values.qMin ?? null,
    qMaxMvar: values.qMax ?? null,
    regionId: null,
    enabled: values.enabled !== false
  };
}

function branch(id, fromNodeId, toNodeId, values = {}) {
  return {
    id,
    fromNodeId,
    toNodeId,
    type: values.type || 'line',
    resistanceOhm: values.r,
    reactanceOhm: values.x,
    chargingSusceptanceMicroS: values.b ?? 0,
    tapRatio: values.tap ?? 1,
    phaseShiftDeg: values.shift ?? 0,
    ratedCurrentA: values.ratedCurrentA ?? null,
    enabled: values.enabled !== false
  };
}

function network220() {
  return {
    name: 'Эталон 220 кВ',
    basePowerMVA: 100,
    nodes: [
      node('1', 'Slack', 220, { voltage: 1 }),
      node('2', 'PQ', 220, { loadP: 80, loadQ: 30 })
    ],
    branches: [branch('1-2', '1', '2', { r: 11.8, x: 40.5, b: 280, ratedCurrentA: 600 })]
  };
}

function simpleTwoBus() {
  return {
    name: 'Два узла',
    basePowerMVA: 100,
    nodes: [
      node('1', 'Slack', 100, { voltage: 1 }),
      node('2', 'PQ', 100, { loadP: 50, loadQ: 20 })
    ],
    branches: [branch('1-2', '1', '2', { r: 1, x: 10 })]
  };
}

function threeBus() {
  return {
    name: 'Slack + PV + PQ',
    basePowerMVA: 100,
    nodes: [
      node('1', 'Slack', 100, { voltage: 1.06 }),
      node('2', 'PV', 100, { voltage: 1.045, generationP: 40, loadP: 20, loadQ: 10, qMin: -40, qMax: 50 }),
      node('3', 'PQ', 100, { loadP: 45, loadQ: 15 })
    ],
    branches: [
      branch('1-2', '1', '2', { r: 2, x: 6, b: 300 }),
      branch('1-3', '1', '3', { r: 8, x: 24, b: 250 }),
      branch('2-3', '2', '3', { r: 6, x: 18, b: 200 })
    ]
  };
}

function transformerNetwork(phaseShiftDeg = 0) {
  return {
    name: `Трансформатор 220/10 кВ, ${phaseShiftDeg}°`,
    basePowerMVA: 100,
    nodes: [
      node('hv', 'Slack', 220, { voltage: 1 }),
      node('lv', 'PQ', 10, { loadP: 10, loadQ: 3 })
    ],
    branches: [branch('T1', 'hv', 'lv', {
      type: 'transformer', r: 4.84, x: 48.4, tap: 1, shift: phaseShiftDeg, ratedCurrentA: 1200
    })]
  };
}

test('двухузловая сеть Slack + PQ сходится и возвращает полный контракт результатов', () => {
  const result = PowerFlow.calculatePowerFlow(simpleTwoBus());
  assert.equal(result.converged, true);
  assert.ok(result.iterations > 0 && result.iterations < 30);
  assert.ok(result.maxMismatch <= 1e-8);
  assert.equal(result.nodeResults.length, 2);
  assert.equal(result.branchResults.length, 1);
  assert.equal(result.nodes, result.nodeResults);
  assert.equal(result.branches, result.branchResults);
  assert.ok(result.totalGeneration.activeMW > result.totalLoad.activeMW);
});

test('сеть 220 кВ совпадает с независимым конечно-разностным эталоном', () => {
  const result = PowerFlow.calculatePowerFlow(network220(), { tolerance: 1e-10 });
  assert.equal(result.converged, true);
  const slack = result.nodeResults[0];
  const load = result.nodeResults[1];
  close(load.voltagePU, REFERENCES.network220.voltage2PU, 1e-9, 'U2');
  close(load.angleDeg, REFERENCES.network220.angle2Deg, 1e-8, 'δ2');
  close(slack.generationPMW, REFERENCES.network220.slackPMW, 1e-7, 'P slack');
  close(slack.generationQMvar, REFERENCES.network220.slackQMvar, 1e-7, 'Q slack');
  close(result.branchResults[0].pToMW, 80, 1e-8, 'P нагрузки');
  close(result.branchResults[0].qToMvar, 30, 1e-8, 'Q нагрузки');
});

test('трёхузловая сеть Slack + PV + PQ совпадает с независимым эталоном', () => {
  const result = PowerFlow.calculatePowerFlow(threeBus(), { tolerance: 1e-10 });
  assert.equal(result.converged, true);
  const [slack, pv, pq] = result.nodeResults;
  assert.equal(pv.busMode, 'PV');
  close(pv.voltagePU, 1.045, 1e-12, 'U PV');
  close(pq.voltagePU, REFERENCES.threeBus.voltage3PU, 1e-9, 'U3');
  close(pv.angleDeg, REFERENCES.threeBus.angle2Deg, 1e-8, 'δ2');
  close(pq.angleDeg, REFERENCES.threeBus.angle3Deg, 1e-8, 'δ3');
  close(slack.generationPMW, REFERENCES.threeBus.slackPMW, 1e-7, 'P slack');
  close(slack.generationQMvar, REFERENCES.threeBus.slackQMvar, 1e-7, 'Q slack');
  close(pv.generationQMvar, REFERENCES.threeBus.pvQMvar, 1e-7, 'Q PV');
});

test('аналитический Якобиан совпадает с центральным численным дифференцированием', () => {
  const model = PowerFlow.buildYBus(threeBus());
  assert.equal(model.ok, true);
  const voltage = [1.06, 1.045, 1.01];
  const angle = [0, 0.02, -0.04];
  const angleIndices = [1, 2];
  const voltageIndices = [2];
  const injections = PowerFlow.calculateInjections(model.ybus, voltage, angle);
  const analytic = PowerFlow.buildJacobian(model.ybus, voltage, angle, injections, angleIndices, voltageIndices);
  const output = (candidateVoltage, candidateAngle) => {
    const values = PowerFlow.calculateInjections(model.ybus, candidateVoltage, candidateAngle);
    return [...angleIndices.map((index) => values[index].p), ...voltageIndices.map((index) => values[index].q)];
  };
  const h = 1e-6;
  const variables = [
    ...angleIndices.map((index) => ({ kind: 'angle', index })),
    ...voltageIndices.map((index) => ({ kind: 'voltage', index }))
  ];
  variables.forEach((variable, column) => {
    const plusVoltage = voltage.slice();
    const minusVoltage = voltage.slice();
    const plusAngle = angle.slice();
    const minusAngle = angle.slice();
    if (variable.kind === 'angle') {
      plusAngle[variable.index] += h;
      minusAngle[variable.index] -= h;
    } else {
      plusVoltage[variable.index] += h;
      minusVoltage[variable.index] -= h;
    }
    const plus = output(plusVoltage, plusAngle);
    const minus = output(minusVoltage, minusAngle);
    plus.forEach((value, row) => close(analytic[row][column], (value - minus[row]) / (2 * h), 2e-7, `J[${row},${column}]`));
  });
});

test('линейная система решается с частичным выбором главного элемента', () => {
  assert.deepEqual(PowerFlow.solveLinearSystem([[0, 2], [1, 1]], [4, 3]), [1, 2]);
});

test('трансформатор 220/10 кВ использует согласованные базы и физические токи сторон', () => {
  const result = PowerFlow.calculatePowerFlow(transformerNetwork(), { tolerance: 1e-11 });
  assert.equal(result.converged, true);
  const low = result.nodeResults[1];
  const transformer = result.branchResults[0];
  close(low.voltagePU, REFERENCES.transformer.voltageLowPU, 1e-10, 'U НН');
  close(low.angleDeg, REFERENCES.transformer.angleLowDeg, 1e-9, 'δ НН');
  close(transformer.activeLossMW, REFERENCES.transformer.activeLossMW, 1e-9, 'ΔP');
  close(transformer.reactiveLossMvar, REFERENCES.transformer.reactiveLossMvar, 1e-9, 'ΔQ');
  assert.ok(transformer.currentToA > transformer.currentFromA * 20);
  assert.equal(transformer.loadingPercent, transformer.currentFromA / 1200 * 100);
  assert.equal(transformer.loadingToPercent, null);
});

test('загрузка трансформатора использует отдельные паспортные токи сторон', () => {
  const network = transformerNetwork();
  Object.assign(network.branches[0], {
    ratedCurrentA: null,
    ratedCurrentFromA: 40,
    ratedCurrentToA: 700
  });
  const result = PowerFlow.calculatePowerFlow(network);
  const transformer = result.branchResults[0];
  close(transformer.loadingFromPercent, transformer.currentFromA / 40 * 100, 1e-10, 'loading from');
  close(transformer.loadingToPercent, transformer.currentToA / 700 * 100, 1e-10, 'loading to');
  close(transformer.loadingPercent, Math.max(transformer.loadingFromPercent, transformer.loadingToPercent), 1e-12, 'loading max');
});

test('положительный фазовый сдвиг tap уменьшает угол узла to на заданную величину', () => {
  const withoutShift = PowerFlow.calculatePowerFlow(transformerNetwork(0), { tolerance: 1e-11 });
  const withShift = PowerFlow.calculatePowerFlow(transformerNetwork(10), { tolerance: 1e-11 });
  assert.equal(withShift.converged, true);
  close(withShift.nodeResults[1].angleDeg, -10.558045607348628, 1e-9, 'δ НН');
  close(withShift.nodeResults[1].angleDeg - withoutShift.nodeResults[1].angleDeg, -10, 1e-9, 'Δδ');
  close(withShift.nodeResults[1].voltagePU, withoutShift.nodeResults[1].voltagePU, 1e-10, 'U НН');
});

test('PV переключается в PQ при Qmin с учётом реактивной нагрузки узла', () => {
  const network = threeBus();
  network.nodes[1].qMinMvar = -5;
  const result = PowerFlow.calculatePowerFlow(network);
  assert.equal(result.converged, true);
  assert.equal(result.nodeResults[1].busMode, 'PQ');
  assert.equal(result.nodeResults[1].reactiveLimitMvar, -5);
  close(result.nodeResults[1].generationQMvar, -5, 1e-6, 'Qг на Qmin');
  assert.ok(Math.abs(result.nodeResults[1].voltagePU - 1.045) > 1e-3);
  assert.equal(result.diagnostics.reactiveLimitEvents[0].limit, 'min');
});

test('PV переключается в PQ при Qmax', () => {
  const network = threeBus();
  network.nodes[1].voltageSetpointPU = 1.08;
  network.nodes[1].qMinMvar = -50;
  network.nodes[1].qMaxMvar = 5;
  const result = PowerFlow.calculatePowerFlow(network);
  assert.equal(result.converged, true);
  assert.equal(result.nodeResults[1].busMode, 'PQ');
  close(result.nodeResults[1].generationQMvar, 5, 1e-6, 'Qг на Qmax');
  assert.equal(result.diagnostics.reactiveLimitEvents[0].limit, 'max');
});

test('отключённая резервная ветвь имеет нулевой ток и не меняет решение', () => {
  const baseline = PowerFlow.calculatePowerFlow(network220(), { tolerance: 1e-10 });
  const network = network220();
  network.branches.push(branch('reserve', '1', '2', { r: 5, x: 20, enabled: false, ratedCurrentA: 10 }));
  const result = PowerFlow.calculatePowerFlow(network, { tolerance: 1e-10 });
  assert.equal(result.converged, true);
  close(result.nodeResults[1].voltagePU, baseline.nodeResults[1].voltagePU, 1e-12, 'U2');
  const reserve = result.branchResults.find((item) => item.id === 'reserve');
  assert.equal(reserve.currentA, 0);
  assert.equal(reserve.loadingPercent, null);
});

test('несвязанный остров блокирует расчёт и не раскрывает фиктивные результаты', () => {
  const network = network220();
  network.nodes.push(node('3', 'PQ', 220, { loadP: 1, loadQ: 0 }));
  const result = PowerFlow.calculatePowerFlow(network);
  assert.equal(result.converged, false);
  assert.equal(result.diagnostics.reason, 'invalid_data');
  assert.ok(result.diagnostics.issues.some((issue) => issue.code === 'multiple_islands'));
  assert.deepEqual(result.nodeResults, []);
  assert.deepEqual(result.branchResults, []);
});

test('лимит итераций возвращает несходимость без последнего приближения в результатах', () => {
  const result = PowerFlow.calculatePowerFlow(network220(), { maxIterations: 1, tolerance: 1e-12 });
  assert.equal(result.converged, false);
  assert.equal(result.diagnostics.reason, 'not_converged');
  assert.equal(result.iterations, 1);
  assert.ok(result.maxMismatch > 1e-12);
  assert.deepEqual(result.nodeResults, []);
  assert.deepEqual(result.branchResults, []);
});

test('балансы P и Q совпадают с суммой потерь ветвей', () => {
  const result = PowerFlow.calculatePowerFlow(threeBus(), { tolerance: 1e-10 });
  assert.equal(result.converged, true);
  close(result.totalGeneration.activeMW - result.totalLoad.activeMW, result.totalLosses.activeMW, 1e-8, 'баланс P');
  close(result.totalGeneration.reactiveMvar - result.totalLoad.reactiveMvar, result.totalLosses.reactiveMvar, 1e-8, 'баланс Q');
  close(result.diagnostics.balance.activeMW, 0, 1e-8, 'остаток P');
  close(result.diagnostics.balance.reactiveMvar, 0, 1e-8, 'остаток Q');
  const sumBranchP = result.branchResults.reduce((sum, item) => sum + item.pijMW + item.pjiMW, 0);
  const sumBranchQ = result.branchResults.reduce((sum, item) => sum + item.qijMvar + item.qjiMvar, 0);
  close(sumBranchP, result.totalLosses.activeMW, 1e-12, 'ΣΔP ветвей');
  close(sumBranchQ, result.totalLosses.reactiveMvar, 1e-12, 'ΣΔQ ветвей');
});

test('некорректные options возвращаются как диагностическая ошибка', () => {
  const result = PowerFlow.calculatePowerFlow(network220(), { tolerance: 0, maxIterations: 1.5 });
  assert.equal(result.converged, false);
  assert.equal(result.diagnostics.reason, 'invalid_options');
  assert.equal(result.diagnostics.messages.length, 2);
});

test('MATPOWER Case 9 совпадает с зафиксированным внешним эталоном', () => {
  // MATPOWER case9 AC PF reference: Vm and Va for buses 1..9.
  const expected = [
    [1.04, 0], [1.025, 9.280005], [1.025, 4.664751],
    [1.025788, -2.216788], [1.012654, -3.687397], [1.032353, 1.966716],
    [1.015883, 0.727537], [1.02577, 3.719701], [0.995631, -3.988805]
  ];
  const result = PowerFlow.calculatePowerFlow(matpowerCase9, { tolerance: 1e-10 });
  assert.equal(result.converged, true);
  assert.ok(result.maxMismatch <= 1e-10);
  result.nodeResults.forEach((nodeResult, index) => {
    close(nodeResult.voltagePU, expected[index][0], 1e-6, `case9 Vm bus ${index + 1}`);
    close(nodeResult.angleDeg, expected[index][1], 6e-6, `case9 Va bus ${index + 1}`);
  });
  close(result.totalGeneration.activeMW, 319.641, 0.002, 'case9 ΣPg');
  close(result.totalGeneration.activeMW - result.totalLoad.activeMW, result.totalLosses.activeMW, 1e-7, 'case9 balance P');
});
