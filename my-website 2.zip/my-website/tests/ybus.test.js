'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const YBus = require('../lib/ybus.js');
const { network220KV } = require('../examples/network-220kv.js');

function closeTo(actual, expected, tolerance = 1e-10) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
}

function node(id, type, nominalVoltageKV) {
  return {
    id, name: id, type, nominalVoltageKV,
    voltageSetpointPU: type === 'Slack' ? 1 : null,
    angleSetpointDeg: type === 'Slack' ? 0 : null,
    loadPMW: 0, loadQMvar: 0,
    generationPMW: type === 'Slack' ? null : 0,
    generationQMvar: type === 'PQ' ? 0 : null,
    qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true
  };
}

test('Ybus двухузловой линии совпадает с эталоном π-схемы', () => {
  const result = YBus.buildYBus({
    name: 'Ybus line reference', basePowerMVA: 100,
    nodes: [node('1', 'Slack', 220), node('2', 'PQ', 220)],
    branches: [{
      id: 'l', name: 'L', fromNodeId: '1', toNodeId: '2', type: 'line',
      resistanceOhm: 4.84, reactanceOhm: 48.4, chargingSusceptanceMicroS: 100,
      tapRatio: 1, phaseShiftDeg: 0, ratedCurrentA: null, enabled: true
    }]
  });
  assert.equal(result.ok, true);
  const expectedG = 0.9900990099009901;
  const expectedSeriesB = -9.900990099009901;
  const halfChargingB = 0.0242;
  closeTo(result.ybus[0][0].re, expectedG);
  closeTo(result.ybus[0][0].im, expectedSeriesB + halfChargingB);
  closeTo(result.ybus[1][1].re, expectedG);
  closeTo(result.ybus[1][1].im, expectedSeriesB + halfChargingB);
  closeTo(result.ybus[0][1].re, -expectedG);
  closeTo(result.ybus[0][1].im, -expectedSeriesB);
  closeTo(result.ybus[1][0].re, -expectedG);
  closeTo(result.ybus[1][0].im, -expectedSeriesB);
});

test('физический legacy-коэффициент 110/220 не попадает в Ybus как tap=0,5', () => {
  const result = YBus.buildYBus({
    name: 'Legacy transformer', baseMVA: 100,
    nodes: [
      { id: 'h', name: 'ВН', type: 'slack', nominalKV: 220, setVoltageKV: 220, setAngleDeg: 0, loadMW: 0, loadMvar: 0, generationMW: 0, generationMvar: 0 },
      { id: 'l', name: 'НН', type: 'load', nominalKV: 110, setVoltageKV: null, setAngleDeg: 0, loadMW: 0, loadMvar: 0, generationMW: 0, generationMvar: 0 }
    ],
    branches: [{ id: 't', name: 'T', from: 'h', to: 'l', type: 'transformer', rOhm: 4.84, xOhm: 48.4, bMicroS: 0, ratio: 0.5, iMaxA: null }]
  });
  assert.equal(result.ok, true);
  assert.equal(result.branchModels.get('t').tapRatio, 1);
  closeTo(result.ybus[0][0].re, 0.9900990099009901);
  closeTo(result.ybus[0][1].re, -0.9900990099009901);
  closeTo(result.ybus[0][1].im, 9.900990099009901);
});

test('трансформатор с tap=1,1 и +10° совпадает с независимым эталоном', () => {
  const result = YBus.buildYBus({
    name: 'Phase shifting transformer', basePowerMVA: 100,
    nodes: [node('h', 'Slack', 220), node('l', 'PQ', 110)],
    branches: [{
      id: 't', name: 'T', fromNodeId: 'h', toNodeId: 'l', type: 'transformer',
      resistanceOhm: 4.84, reactanceOhm: 48.4, chargingSusceptanceMicroS: 0,
      tapRatio: 1.1, phaseShiftDeg: 10, ratedCurrentA: null, enabled: true
    }]
  });
  assert.equal(result.ok, true);
  closeTo(result.ybus[0][0].re, 0.818263644546273);
  closeTo(result.ybus[0][0].im, -8.18263644546273);
  closeTo(result.ybus[0][1].re, -2.4494055172650873);
  closeTo(result.ybus[0][1].im, 8.70785720292993);
  closeTo(result.ybus[1][0].re, 0.676574278719258);
  closeTo(result.ybus[1][0].im, 9.020455182528364);
  closeTo(result.ybus[1][1].re, 0.9900990099009903);
  closeTo(result.ybus[1][1].im, -9.900990099009903);
  assert.equal(result.tapConvention.side, 'fromNodeId');
});

test('эталон 220 кВ формирует Ybus без ошибок', () => {
  const result = YBus.buildYBus(network220KV);
  assert.equal(result.ok, true);
  assert.equal(result.ybus.length, 2);
  assert.equal(result.index.get('bus-1'), 0);
  assert.equal(result.index.get('bus-2'), 1);
  assert.equal(result.diagnostics.errors.length, 0);
});

test('Ybus не строится при блокирующей ошибке', () => {
  const invalid = JSON.parse(JSON.stringify(network220KV));
  invalid.branches[0].reactanceOhm = 0;
  invalid.branches[0].resistanceOhm = 0;
  const result = YBus.buildYBus(invalid);
  assert.equal(result.ok, false);
  assert.equal(result.ybus, null);
  assert.equal(result.diagnostics.errors.some((issue) => issue.code === 'zero_branch_impedance'), true);
});
