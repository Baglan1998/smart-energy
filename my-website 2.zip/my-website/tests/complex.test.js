'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Complex = require('../lib/complex.js');

function closeTo(actual, expected, tolerance = 1e-12) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
}

test('сложение, вычитание и сопряжение комплексных чисел', () => {
  const a = Complex.create(3, 4);
  const b = Complex.create(1, -2);

  assert.deepEqual(Complex.add(a, b), { re: 4, im: 2 });
  assert.deepEqual(Complex.subtract(a, b), { re: 2, im: 6 });
  assert.deepEqual(Complex.conjugate(a), { re: 3, im: -4 });
  assert.equal(Object.isFrozen(a), true);
});

test('умножение и деление комплексных чисел', () => {
  assert.deepEqual(Complex.multiply(Complex.create(3, 4), Complex.create(1, -2)), { re: 11, im: -2 });
  const quotient = Complex.divide(Complex.create(-1, 2), Complex.create(3, 4));
  closeTo(quotient.re, 0.2);
  closeTo(quotient.im, 0.4);
});

test('перевод между алгебраической и полярной формами', () => {
  const value = Complex.fromPolar(2, Math.PI / 6);
  closeTo(value.re, Math.sqrt(3));
  closeTo(value.im, 1);

  const polar = Complex.toPolar(value);
  closeTo(polar.magnitude, 2);
  closeTo(polar.angleRad, Math.PI / 6);
  closeTo(polar.angleDeg, 30);
  closeTo(Complex.magnitude(Complex.create(3, 4)), 5);
  closeTo(Complex.argument(Complex.create(0, 1)), Math.PI / 2);
});

test('нулевой делитель и неконечные числа отклоняются', () => {
  assert.throws(() => Complex.divide(Complex.create(1, 1), Complex.create(0, 0)), RangeError);
  assert.throws(() => Complex.create(Number.NaN, 0), TypeError);
  assert.throws(() => Complex.create(0, Number.POSITIVE_INFINITY), TypeError);
  assert.throws(() => Complex.fromPolar(-1, 0), RangeError);
});
