'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const PerUnit = require('../lib/per-unit.js');

function closeTo(actual, expected, tolerance = 1e-12) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);
}

test('базисы 220 кВ и 100 МВА имеют корректные единицы', () => {
  const base = PerUnit.calculateBaseValues({ basePowerMVA: 100, baseVoltageKV: 220 });
  closeTo(base.impedanceBaseOhm, 484);
  closeTo(base.currentBaseKA, 100 / (Math.sqrt(3) * 220));
  closeTo(base.currentBaseA, 262.431940540739);
  closeTo(base.admittanceBaseSiemens, 1 / 484);
});

test('импеданс и проводимость переводятся в per-unit', () => {
  const impedance = PerUnit.impedanceToPerUnit({
    resistanceOhm: 4.84, reactanceOhm: 48.4, basePowerMVA: 100, baseVoltageKV: 220
  });
  closeTo(impedance.resistancePU, 0.01);
  closeTo(impedance.reactancePU, 0.1);

  const admittance = PerUnit.admittanceToPerUnit({
    conductanceSiemens: 0, susceptanceSiemens: 100e-6, basePowerMVA: 100, baseVoltageKV: 220
  });
  closeTo(admittance.susceptancePU, 0.0484);
});

test('обратные преобразования возвращают А, кВ, МВт и Мвар', () => {
  closeTo(PerUnit.voltageKVToPerUnit(209, 220), 0.95);
  closeTo(PerUnit.voltagePUToKV(0.95, 220), 209);
  closeTo(PerUnit.currentPUToA(1, 100, 220), 262.431940540739);
  closeTo(PerUnit.currentAToPerUnit(262.431940540739, 100, 220), 1);
  closeTo(PerUnit.powerMWToPerUnit(80, 100), 0.8);
  closeTo(PerUnit.powerMvarToPerUnit(30, 100), 0.3);
  closeTo(PerUnit.powerPUToMW(0.8, 100), 80);
  closeTo(PerUnit.powerPUToMvar(0.3, 100), 30);
});

test('неверные базисы не заменяются нулями', () => {
  assert.throws(() => PerUnit.calculateBaseValues({ basePowerMVA: null, baseVoltageKV: 220 }), TypeError);
  assert.throws(() => PerUnit.calculateBaseValues({ basePowerMVA: 100, baseVoltageKV: 0 }), RangeError);
  assert.throws(() => PerUnit.impedanceToPerUnit({ resistanceOhm: Number.NaN, reactanceOhm: 1, basePowerMVA: 100, baseVoltageKV: 220 }), TypeError);
});
