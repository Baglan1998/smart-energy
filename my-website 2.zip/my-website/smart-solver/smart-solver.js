(function initializeSmartSolver(global) {
  'use strict';

  if (!global.NetworkModel || !global.YBus || !global.PowerFlow) {
    throw new Error('Smart Solver требует NetworkModel, YBus и PowerFlow.');
  }

  const PROJECTS_KEY = 'smartEnergySmartSolverProjectsV4';
  const SNAPSHOTS_KEY = 'smartEnergySmartSolverSnapshotsV4';
  const root = document.querySelector('[data-smart-solver]');
  const viewRoot = document.getElementById('solverView');
  const statusRoot = document.getElementById('solverStatus');
  const projectNameInput = document.getElementById('solverProjectName');
  const projectSelect = document.getElementById('solverProjectSelect');
  const importInput = document.getElementById('solverImportFile');
  const nodeDialog = document.getElementById('solverNodeDialog');
  const nodeForm = document.getElementById('solverNodeForm');
  const branchDialog = document.getElementById('solverBranchDialog');
  const branchForm = document.getElementById('solverBranchForm');
  let idSequence = 0;
  let toastTimer = null;

  const state = {
    projectId: null,
    network: null,
    layout: {},
    result: null,
    diagnostics: null,
    resultStale: false,
    dirty: false,
    view: 'overview',
    snapshots: readJson(SNAPSHOTS_KEY, { A: null, B: null }),
    diagram: {
      mode: 'input', zoom: 1, panX: 0, panY: 0,
      visibility: { nominal: true, calculated: true, angle: true, flows: true, loading: true, power: true }
    }
  };

  function readJson(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch (error) { return fallback; }
  }

  function writeJson(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (error) { return false; }
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function uid(prefix) { idSequence += 1; return `${prefix}_${Date.now().toString(36)}_${idSequence.toString(36)}`; }
  function esc(value) { return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char]); }
  function fmt(value, digits = 3) { return Number.isFinite(value) ? new Intl.NumberFormat('ru-RU', { maximumFractionDigits: digits }).format(value) : '—'; }
  function nullable(value) { const text = String(value ?? '').trim(); if (!text) return null; const number = Number(text); return Number.isFinite(number) ? number : Number.NaN; }
  function valueOrBlank(value) {
    if (value === null || value === undefined) return '';
    if (typeof value === 'number' && !Number.isFinite(value)) return '';
    return String(value);
  }
  function nodeById(id) { return state.network.nodes.find((node) => String(node.id) === String(id)); }
  function resultNode(id) { return state.result?.nodeResults.find((node) => String(node.id) === String(id)) || null; }
  function resultBranch(id) { return state.result?.branchResults.find((branch) => String(branch.id) === String(id)) || null; }

  function blankNetwork() {
    return {
      schemaVersion: global.NetworkModel.SCHEMA_VERSION,
      name: 'Новый проект', basePowerMVA: 100, nodes: [], branches: [],
      settings: { tolerance: 1e-8, maxIterations: 30, pivotTolerance: 1e-12, qLimitToleranceMvar: 1e-6 }
    };
  }

  function exampleNetwork() {
    return {
      schemaVersion: global.NetworkModel.SCHEMA_VERSION,
      name: 'Эталон 220 кВ', basePowerMVA: 100,
      nodes: [
        { id: 'bus-1', name: 'Система 220 кВ', type: 'Slack', nominalVoltageKV: 220, voltageSetpointPU: 1, angleSetpointDeg: 0, loadPMW: 0, loadQMvar: 0, generationPMW: null, generationQMvar: null, qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true },
        { id: 'bus-2', name: 'Нагрузка 80 + j30', type: 'PQ', nominalVoltageKV: 220, voltageSetpointPU: null, angleSetpointDeg: null, loadPMW: 80, loadQMvar: 30, generationPMW: 0, generationQMvar: 0, qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true }
      ],
      branches: [
        { id: 'line-1-2', name: 'ВЛ 1–2, АС-240/32', fromNodeId: 'bus-1', toNodeId: 'bus-2', type: 'line', resistanceOhm: 11.8, reactanceOhm: 40.5, chargingSusceptanceMicroS: 280, tapRatio: 1, phaseShiftDeg: 0, ratedCurrentA: 600, ratedCurrentFromA: 600, ratedCurrentToA: 600, enabled: true }
      ],
      settings: { tolerance: 1e-8, maxIterations: 30, pivotTolerance: 1e-12, qLimitToleranceMvar: 1e-6 }
    };
  }

  function normalizeMutable(input) {
    const source = clone(input || {});
    if (source.basePowerMVA == null && source.baseMVA == null) source.basePowerMVA = 100;
    const normalized = clone(global.NetworkModel.normalizeNetwork(source));
    normalized.settings = {
      tolerance: source.settings?.tolerance ?? source.settings?.powerFlow?.tolerance ?? 1e-8,
      maxIterations: source.settings?.maxIterations ?? source.settings?.powerFlow?.maxIterations ?? 30,
      pivotTolerance: source.settings?.pivotTolerance ?? 1e-12,
      qLimitToleranceMvar: source.settings?.qLimitToleranceMvar ?? 1e-6
    };
    return normalized;
  }

  function setProject(network, layout = {}, projectId = null) {
    state.network = normalizeMutable(network);
    state.projectId = projectId;
    state.layout = clone(layout || {});
    state.result = null;
    state.diagnostics = null;
    state.resultStale = false;
    state.dirty = false;
    state.diagram.zoom = 1;
    state.diagram.panX = 0;
    state.diagram.panY = 0;
    projectNameInput.value = state.network.name || 'Без названия';
    ensureLayout();
    renderAll();
  }

  function markChanged({ electrical = true } = {}) {
    state.dirty = true;
    if (electrical && state.result) {
      state.result = null;
      state.resultStale = true;
    }
    renderStatus();
  }

  function showToast(message, kind = '') {
    document.querySelector('.solver4-toast')?.remove();
    const toast = document.createElement('div');
    toast.className = `solver4-toast ${kind}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.remove(), 3200);
  }

  function renderStatus() {
    let kind = 'idle';
    let title = 'Исходные данные готовы к проверке';
    let detail = 'Результатов расчёта пока нет.';
    if (state.resultStale) { kind = 'warning'; title = 'Результаты устарели'; detail = 'Сеть изменена. Выполните новый расчёт.'; }
    if (state.diagnostics && !state.result) {
      const errors = state.diagnostics.errors?.length || (state.diagnostics.reason && state.diagnostics.reason !== 'converged' ? 1 : 0);
      if (errors) { kind = 'error'; title = 'Расчёт не выполнен'; detail = state.diagnostics.errors?.[0]?.message || state.diagnostics.messages?.[0] || 'Проверьте исходные данные.'; }
    }
    if (state.result?.converged) {
      kind = 'success'; title = 'Режим сошёлся';
      detail = `${state.result.iterations} ит. · max Δ=${state.result.maxMismatch.toExponential(3)} p.u. · ${fmt(state.result.elapsedMs, 2)} мс`;
    }
    statusRoot.dataset.kind = kind;
    statusRoot.querySelector('strong').textContent = title;
    statusRoot.querySelector('span').textContent = detail;
  }

  function diagnostics() { return global.NetworkModel.validateNetwork(state.network); }
  function activeNodes() { return state.network.nodes.filter((node) => node.enabled !== false); }
  function activeBranches() { return state.network.branches.filter((branch) => branch.enabled !== false); }

  function renderAll() {
    projectNameInput.value = state.network.name || '';
    renderProjectSelect();
    renderStatus();
    document.querySelectorAll('[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === state.view));
    renderView();
  }

  function viewHeader(title, description, actions = '') {
    return `<div class="solver4-view-head"><div><h2>${esc(title)}</h2><p>${esc(description)}</p></div><div class="solver4-view-actions">${actions}</div></div>`;
  }

  function issueList(report) {
    const issues = [...(report.errors || []), ...(report.warnings || [])];
    if (!issues.length) return '<div class="solver4-ok">✓ Блокирующих ошибок и предупреждений не обнаружено.</div>';
    return `<div class="solver4-diagnostics">${issues.map((issue) => `<div class="solver4-issue ${issue.severity === 'warning' ? 'warning' : ''}"><b>${issue.severity === 'warning' ? '!' : '×'}</b><span>${esc(issue.message)}</span></div>`).join('')}</div>`;
  }

  function renderOverview() {
    const report = diagnostics();
    const nodeCount = state.network.nodes.length;
    const branchCount = state.network.branches.length;
    const transformerCount = state.network.branches.filter((branch) => branch.type === 'transformer').length;
    const loadP = state.network.nodes.reduce((sum, node) => sum + (Number.isFinite(node.loadPMW) ? node.loadPMW : 0), 0);
    const resultCards = state.result ? `
      <div class="solver4-kpi" data-accent="green"><span>Сходимость</span><strong>${state.result.iterations} ит.</strong><small>${state.result.maxMismatch.toExponential(2)} p.u.</small></div>
      <div class="solver4-kpi" data-accent="yellow"><span>Потери P</span><strong>${fmt(state.result.totalLosses.activeMW, 4)}</strong><small>МВт</small></div>` : '';
    viewRoot.innerHTML = `<div class="solver4-view">
      ${viewHeader('Обзор сети', 'Состав проекта, готовность исходных данных и состояние последнего расчёта.', '<button class="secondary-button" data-action="load-example">Загрузить пример 220 кВ</button><button class="secondary-button" data-action="validate">Проверить данные</button>')}
      <div class="solver4-kpis">
        <div class="solver4-kpi" data-accent="blue"><span>Узлы</span><strong>${nodeCount}</strong><small>активно ${activeNodes().length}</small></div>
        <div class="solver4-kpi" data-accent="blue"><span>Ветви</span><strong>${branchCount}</strong><small>активно ${activeBranches().length}</small></div>
        <div class="solver4-kpi"><span>Трансформаторы</span><strong>${transformerCount}</strong><small>единиц</small></div>
        <div class="solver4-kpi"><span>Нагрузка</span><strong>${fmt(loadP, 2)}</strong><small>МВт</small></div>
        <div class="solver4-kpi" data-accent="${report.ok ? 'green' : 'red'}"><span>Диагностика</span><strong>${report.ok ? 'ГОТОВО' : `${report.errors.length} ош.`}</strong><small>${report.warnings.length} предупрежд.</small></div>
        ${resultCards}
      </div>
      <div class="solver4-grid-2">
        <article class="solver4-card"><div class="solver4-card-head"><div><h3>Исходные данные</h3><p>Хранятся отдельно от результатов расчёта</p></div></div>
          <div class="solver4-table-wrap"><table class="solver4-table"><tbody>
            <tr><th>Название</th><td>${esc(state.network.name || '—')}</td></tr><tr><th>Sbase</th><td>${fmt(state.network.basePowerMVA, 3)} МВА</td></tr>
            <tr><th>Slack</th><td>${state.network.nodes.filter((node) => node.type === 'Slack' && node.enabled).map((node) => esc(node.name || node.id)).join(', ') || '—'}</td></tr>
            <tr><th>Острова</th><td>${report.islands?.length ?? '—'}</td></tr><tr><th>Состояние проекта</th><td>${state.dirty ? 'Есть несохранённые изменения' : 'Сохранён'}</td></tr>
          </tbody></table></div>
        </article>
        <article class="solver4-card"><div class="solver4-card-head"><div><h3>Диагностика сети</h3><p>Ошибки блокируют расчёт, предупреждения требуют проверки</p></div></div>${issueList(report)}</article>
      </div>
    </div>`;
  }

  function nodeTableRows() {
    return state.network.nodes.map((node) => `<tr>
      <td><span class="solver4-pill ${node.enabled ? '' : 'off'}">${node.enabled ? node.type : 'Откл.'}</span></td><td>${esc(node.id)}</td><td>${esc(node.name || '—')}</td>
      <td>${fmt(node.nominalVoltageKV, 3)}</td><td>${fmt(node.voltageSetpointPU, 5)}</td><td>${fmt(node.angleSetpointDeg, 4)}</td>
      <td>${fmt(node.loadPMW, 3)}</td><td>${fmt(node.loadQMvar, 3)}</td><td>${fmt(node.generationPMW, 3)}</td><td>${fmt(node.generationQMvar, 3)}</td>
      <td>${fmt(node.qMinMvar, 3)}</td><td>${fmt(node.qMaxMvar, 3)}</td><td><div class="solver4-table-actions"><button data-action="edit-node" data-id="${esc(node.id)}">Изменить</button><button class="danger" data-action="delete-node" data-id="${esc(node.id)}">Удалить</button></div></td>
    </tr>`).join('');
  }

  function renderNodes() {
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Узлы', 'Slack, PQ и PV. Пустые значения остаются null.', '<button class="primary-button" data-action="add-node">+ Добавить узел</button>')}
      ${state.network.nodes.length ? `<div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Тип</th><th>ID</th><th>Название</th><th>Uном, кВ</th><th>Uзад, p.u.</th><th>δзад, °</th><th>Pн</th><th>Qн</th><th>Pг</th><th>Qг</th><th>Qmin</th><th>Qmax</th><th>Действия</th></tr></thead><tbody>${nodeTableRows()}</tbody></table></div>` : '<div class="solver4-empty"><strong>Узлов пока нет</strong><span>Добавьте Slack-узел, затем нагрузочные или генераторные узлы.</span></div>'}
    </div>`;
  }

  function branchTableRows(branches = state.network.branches) {
    return branches.map((branch) => `<tr>
      <td><span class="solver4-pill ${branch.enabled ? '' : 'off'}">${branch.enabled ? (branch.type === 'line' ? 'ЛЭП' : 'Т') : 'Откл.'}</span></td><td>${esc(branch.id)}</td><td>${esc(branch.name || '—')}</td><td>${esc(nodeById(branch.fromNodeId)?.name || branch.fromNodeId)}</td><td>${esc(nodeById(branch.toNodeId)?.name || branch.toNodeId)}</td>
      <td>${fmt(branch.resistanceOhm, 5)}</td><td>${fmt(branch.reactanceOhm, 5)}</td><td>${fmt(branch.chargingSusceptanceMicroS, 3)}</td><td>${fmt(branch.tapRatio, 5)}</td><td>${fmt(branch.phaseShiftDeg, 3)}</td>
      <td>${fmt(branch.ratedCurrentFromA ?? branch.ratedCurrentA, 2)}</td><td>${fmt(branch.ratedCurrentToA, 2)}</td><td><div class="solver4-table-actions"><button data-action="toggle-branch" data-id="${esc(branch.id)}">${branch.enabled ? 'Отключить' : 'Включить'}</button><button data-action="edit-branch" data-id="${esc(branch.id)}">Изменить</button><button class="danger" data-action="delete-branch" data-id="${esc(branch.id)}">Удалить</button></div></td>
    </tr>`).join('');
  }

  function renderBranches(filter = null) {
    const branches = filter ? state.network.branches.filter(filter) : state.network.branches;
    const title = filter ? 'Трансформаторы' : 'Ветви';
    const description = filter ? 'Отдельные паспортные токи сторон и off-nominal tap.' : 'Линии и трансформаторы. R/X/B задаются в физических единицах.';
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader(title, description, `<button class="primary-button" data-action="add-branch" data-type="${filter ? 'transformer' : 'line'}">+ ${filter ? 'Трансформатор' : 'Ветвь'}</button>`)}
      ${branches.length ? `<div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Тип</th><th>ID</th><th>Название</th><th>Начало</th><th>Конец</th><th>R, Ом</th><th>X, Ом</th><th>B, мкСм</th><th>tap</th><th>θ, °</th><th>Imax from</th><th>Imax to</th><th>Действия</th></tr></thead><tbody>${branchTableRows(branches)}</tbody></table></div>` : `<div class="solver4-empty"><strong>${filter ? 'Трансформаторов' : 'Ветвей'} пока нет</strong><span>Добавьте оборудование между существующими узлами.</span></div>`}
    </div>`;
  }

  function renderPower() {
    const rows = state.network.nodes.map((node) => { const result = resultNode(node.id); return `<tr><td>${esc(node.name || node.id)}</td><td>${esc(node.type)}</td><td>${fmt(node.loadPMW, 3)}</td><td>${fmt(node.loadQMvar, 3)}</td><td>${fmt(node.generationPMW, 3)}</td><td>${fmt(node.generationQMvar, 3)}</td><td>${result ? fmt(result.generationPMW, 3) : '—'}</td><td>${result ? fmt(result.generationQMvar, 3) : '—'}</td><td>${result ? esc(result.busMode) : '—'}</td></tr>`; }).join('');
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Нагрузки и генерация', 'Исходные P/Q показаны отдельно от рассчитанной генерации Slack и PV.')}
      ${state.network.nodes.length ? `<div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Узел</th><th>Тип</th><th>Pн, МВт</th><th>Qн, Мвар</th><th>Pг исход.</th><th>Qг исход.</th><th>Pг расч.</th><th>Qг расч.</th><th>Режим</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="solver4-empty"><strong>Нет исходных данных</strong></div>'}
    </div>`;
  }

  function renderResults() {
    if (!state.result) {
      viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Результаты', 'Напряжения, мощности, токи и потери появляются только после успешного расчёта.')}<div class="solver4-empty"><strong>${state.resultStale ? 'Результаты устарели' : 'Нет результатов расчёта'}</strong><span>${state.resultStale ? 'Сеть была изменена. Выполните расчёт повторно.' : 'Нажмите «Рассчитать режим».'}</span></div></div>`;
      return;
    }
    const nodeRows = state.result.nodeResults.map((node) => `<tr><td>${esc(node.name || node.id)}</td><td>${fmt(nodeById(node.id)?.nominalVoltageKV, 3)}</td><td>${fmt(node.voltageKV, 4)}</td><td>${fmt(node.voltagePU, 6)}</td><td>${fmt(node.angleDeg, 6)}</td><td>${fmt(node.loadPMW, 3)}</td><td>${fmt(node.loadQMvar, 3)}</td><td>${fmt(node.generationPMW, 3)}</td><td>${fmt(node.generationQMvar, 3)}</td></tr>`).join('');
    const branchRows = state.result.branchResults.map((branch) => `<tr><td>${esc(nodeById(branch.fromNodeId)?.name || branch.fromNodeId)}</td><td>${esc(nodeById(branch.toNodeId)?.name || branch.toNodeId)}</td><td>${fmt(branch.pijMW, 4)}</td><td>${fmt(branch.qijMvar, 4)}</td><td>${fmt(branch.pjiMW, 4)}</td><td>${fmt(branch.qjiMvar, 4)}</td><td>${fmt(branch.currentFromA, 3)}</td><td>${fmt(branch.currentToA, 3)}</td><td>${fmt(branch.activeLossMW, 5)}</td><td>${fmt(branch.reactiveLossMvar, 5)}</td><td>${branch.loadingPercent == null ? '—' : `${fmt(branch.loadingPercent, 2)} %`}</td></tr>`).join('');
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Результаты', 'Значения получены из Newton–Raphson и потоков полной π-модели.', '<button class="secondary-button" data-action="export-csv">Экспорт CSV</button>')}
      <div class="solver4-kpis"><div class="solver4-kpi" data-accent="green"><span>Итерации</span><strong>${state.result.iterations}</strong><small>Newton–Raphson</small></div><div class="solver4-kpi"><span>max Δ</span><strong>${state.result.maxMismatch.toExponential(2)}</strong><small>p.u.</small></div><div class="solver4-kpi"><span>Время</span><strong>${fmt(state.result.elapsedMs, 2)}</strong><small>мс</small></div><div class="solver4-kpi" data-accent="yellow"><span>ΔP</span><strong>${fmt(state.result.totalLosses.activeMW, 4)}</strong><small>МВт</small></div><div class="solver4-kpi"><span>ΔQ</span><strong>${fmt(state.result.totalLosses.reactiveMvar, 4)}</strong><small>Мвар</small></div></div>
      <article class="solver4-card"><div class="solver4-card-head"><div><h3>Узлы</h3><p>Исходные нагрузки и рассчитанная генерация</p></div></div><div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Узел</th><th>Uном</th><th>Uрасч</th><th>U, p.u.</th><th>δ, °</th><th>Pн</th><th>Qн</th><th>Pг</th><th>Qг</th></tr></thead><tbody>${nodeRows}</tbody></table></div></article>
      <article class="solver4-card"><div class="solver4-card-head"><div><h3>Ветви</h3><p>Pji/Qji имеют знак инъекции от конечного узла к ветви</p></div></div><div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Начало</th><th>Конец</th><th>Pij</th><th>Qij</th><th>Pji</th><th>Qji</th><th>Iij, А</th><th>Iji, А</th><th>ΔP</th><th>ΔQ</th><th>Загрузка</th></tr></thead><tbody>${branchRows}</tbody></table></div></article>
    </div>`;
  }

  function ensureLayout(force = false) {
    const nodes = state.network.nodes;
    const columns = Math.max(1, Math.ceil(Math.sqrt(nodes.length || 1)));
    nodes.forEach((node, index) => {
      if (!force && state.layout[node.id] && Number.isFinite(state.layout[node.id].x) && Number.isFinite(state.layout[node.id].y)) return;
      state.layout[node.id] = { x: 150 + (index % columns) * 280, y: 120 + Math.floor(index / columns) * 210 };
    });
    Object.keys(state.layout).forEach((id) => { if (!nodes.some((node) => String(node.id) === String(id))) delete state.layout[id]; });
  }

  function diagramSvg() {
    ensureLayout();
    const resultMode = state.diagram.mode === 'result';
    const visibility = state.diagram.visibility;
    const branches = state.network.branches.map((branch) => {
      const from = state.layout[branch.fromNodeId]; const to = state.layout[branch.toNodeId];
      if (!from || !to) return '';
      const result = resultBranch(branch.id);
      const reverse = resultMode && result && result.pijMW < 0;
      const ax = reverse ? to.x : from.x; const ay = reverse ? to.y : from.y;
      const bx = reverse ? from.x : to.x; const by = reverse ? from.y : to.y;
      const mx = (from.x + to.x) / 2; const my = (from.y + to.y) / 2;
      const overloaded = result?.loadingPercent > 100;
      const flow = resultMode && result && visibility.flows ? `${fmt(Math.abs(result.pijMW), 2)} MW · ${fmt(result.qijMvar, 2)} Mvar` : `${fmt(branch.resistanceOhm, 3)} + j${fmt(branch.reactanceOhm, 3)} Ω`;
      const loading = resultMode && result && visibility.loading && result.loadingPercent != null ? `<text class="solver4-flow-label" x="${mx}" y="${my + 17}" text-anchor="middle">${fmt(result.loadingPercent, 1)} %</text>` : '';
      const symbol = branch.type === 'transformer' ? `<circle class="solver4-transformer-symbol" cx="${mx - 8}" cy="${my}" r="11"></circle><circle class="solver4-transformer-symbol" cx="${mx + 8}" cy="${my}" r="11"></circle>` : '';
      return `<g><line class="solver4-branch-line ${branch.enabled ? '' : 'off'} ${overloaded ? 'overloaded' : ''}" x1="${from.x}" y1="${from.y}" x2="${to.x}" y2="${to.y}"></line>${resultMode && result && visibility.flows && branch.enabled ? `<line class="solver4-branch-line ${overloaded ? 'overloaded' : ''}" x1="${ax}" y1="${ay}" x2="${bx}" y2="${by}" marker-end="url(#solverArrow)"></line>` : ''}${symbol}<text class="solver4-flow-label" x="${mx}" y="${my - 14}" text-anchor="middle">${esc(branch.name || branch.id)}</text><text class="solver4-flow-label" x="${mx}" y="${my + 4}" text-anchor="middle">${esc(flow)}</text>${loading}</g>`;
    }).join('');
    const nodes = state.network.nodes.map((node) => {
      const point = state.layout[node.id]; const result = resultNode(node.id);
      const calculated = resultMode && result;
      const lines = [];
      if (visibility.nominal) lines.push(`Uном ${fmt(node.nominalVoltageKV, 2)} кВ`);
      if (visibility.calculated) lines.push(calculated ? `U ${fmt(result.voltageKV, 2)} кВ · ${fmt(result.voltagePU, 4)} pu` : 'Uрасч —');
      if (visibility.angle) lines.push(calculated ? `δ ${fmt(result.angleDeg, 3)}°` : 'δ —');
      if (visibility.power) {
        if (Number.isFinite(node.loadPMW) && (node.loadPMW || node.loadQMvar)) lines.push(`↓ ${fmt(node.loadPMW, 1)} + j${fmt(node.loadQMvar, 1)}`);
        if (calculated && (result.generationPMW || result.generationQMvar)) lines.push(`↑ ${fmt(result.generationPMW, 1)} + j${fmt(result.generationQMvar, 1)}`);
      }
      const generatorSymbol = node.type === 'Slack' || node.type === 'PV' ? '<circle class="solver4-equipment-symbol" cx="-63" cy="-66" r="13"></circle><text x="-63" y="-62" text-anchor="middle" font-size="10" font-weight="800">G</text>' : '';
      const loadSymbol = (node.loadPMW || node.loadQMvar) ? '<path class="solver4-equipment-symbol" d="M52 -78 74 -78 63 -56Z"></path>' : '';
      return `<g class="solver4-node ${node.type.toLowerCase()}" data-node-id="${esc(node.id)}" transform="translate(${point.x} ${point.y})">${generatorSymbol}${loadSymbol}<rect class="solver4-node-bus" x="-78" y="-51" width="156" height="102" rx="11"></rect><text x="0" y="-31" text-anchor="middle" font-size="12" font-weight="700">${esc(node.name || node.id)}</text>${lines.slice(0, 5).map((line, index) => `<text class="secondary" x="0" y="${-12 + index * 14}" text-anchor="middle">${esc(line)}</text>`).join('')}</g>`;
    }).join('');
    return `<svg id="solverDiagramSvg" viewBox="0 0 1000 620" role="img" aria-label="Однолинейная схема электрической сети"><defs><marker id="solverArrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="var(--primary)"></path></marker></defs><g id="solverDiagramWorld" transform="translate(${state.diagram.panX} ${state.diagram.panY}) scale(${state.diagram.zoom})">${branches}${nodes}</g></svg>`;
  }

  function renderDiagram() {
    const checks = Object.entries({ nominal: 'Uном', calculated: 'Uрасч', angle: 'δ', flows: 'P/Q', loading: 'Загрузка', power: 'Нагрузка/генерация' }).map(([key, label]) => `<label><input type="checkbox" data-visibility="${key}" ${state.diagram.visibility[key] ? 'checked' : ''}>${label}</label>`).join('');
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Однолинейная схема', 'SVG отображает только исходные данные и результаты общего расчётного ядра.')}
      <article class="solver4-card solver4-diagram-panel"><div class="solver4-diagram-toolbar"><div><button class="${state.diagram.mode === 'input' ? 'active' : ''}" data-action="diagram-mode" data-mode="input">Исходные данные</button><button class="${state.diagram.mode === 'result' ? 'active' : ''}" data-action="diagram-mode" data-mode="result" ${state.result ? '' : 'disabled'}>Результаты</button></div><div><button data-action="diagram-zoom-in">＋</button><button data-action="diagram-zoom-out">−</button><button data-action="diagram-fit">По размеру</button><button data-action="diagram-auto">Автораскладка</button></div></div><div class="solver4-visibility">${checks}</div><div class="solver4-diagram-stage">${diagramSvg()}</div></article>
    </div>`;
    bindDiagramInteractions();
  }

  function barChart(title, subtitle, items) {
    const width = 620; const rowHeight = 31; const height = Math.max(180, 55 + items.length * rowHeight); const center = 310; const max = Math.max(...items.map((item) => Math.abs(item.value)), 1e-12); const scale = 235 / max;
    const rows = items.map((item, index) => { const y = 38 + index * rowHeight; const length = Math.abs(item.value) * scale; const x = item.value >= 0 ? center : center - length; const cls = item.className || (item.value < 0 ? 'danger' : ''); return `<text x="4" y="${y + 11}">${esc(item.label)}</text><rect class="bar ${cls}" x="${x}" y="${y}" width="${length}" height="15" rx="3"></rect><text x="${item.value >= 0 ? Math.min(width - 66, x + length + 6) : Math.max(155, x - 62)}" y="${y + 11}">${fmt(item.value, item.digits ?? 3)}</text>`; }).join('');
    return `<article class="solver4-chart"><h3>${esc(title)}</h3><p>${esc(subtitle)}</p><svg viewBox="0 0 ${width} ${height}" aria-label="${esc(title)}"><line class="axis" x1="${center}" y1="22" x2="${center}" y2="${height - 10}"></line>${rows}</svg></article>`;
  }

  function renderCharts() {
    if (!state.result) { viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Графики', 'Все графики строятся исключительно из результатов расчёта.')}<div class="solver4-empty"><strong>Нет результатов расчёта</strong><span>Графики не используют исходные или фиктивные значения.</span></div></div>`; return; }
    const n = state.result.nodeResults; const b = state.result.branchResults.filter((item) => item.enabled);
    const charts = [
      barChart('Напряжения узлов', 'p.u.', n.map((item) => ({ label: item.name || item.id, value: item.voltagePU }))),
      barChart('Углы напряжения', 'градусы', n.map((item) => ({ label: item.name || item.id, value: item.angleDeg }))),
      barChart('Загрузка ветвей', '% только при заданных Imax', b.map((item) => ({ label: item.id, value: item.loadingPercent ?? 0, className: item.loadingPercent > 100 ? 'danger' : item.loadingPercent >= 80 ? 'warning' : '' }))),
      barChart('Активные потери', 'МВт', b.map((item) => ({ label: item.id, value: item.activeLossMW, digits: 5 }))),
      barChart('Реактивные потери', 'Мвар; могут быть отрицательными из-за B', b.map((item) => ({ label: item.id, value: item.reactiveLossMvar, digits: 5 }))),
      barChart('Баланс P и Q', 'МВт / Мвар', [
        { label: 'P генерация', value: state.result.totalGeneration.activeMW }, { label: 'P нагрузка', value: state.result.totalLoad.activeMW, className: 'alt' }, { label: 'P потери', value: state.result.totalLosses.activeMW, className: 'warning' },
        { label: 'Q генерация', value: state.result.totalGeneration.reactiveMvar }, { label: 'Q нагрузка', value: state.result.totalLoad.reactiveMvar, className: 'alt' }, { label: 'Q потери', value: state.result.totalLosses.reactiveMvar, className: 'warning' }
      ])
    ].join('');
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Графики', 'Напряжения, углы, загрузка, потери и баланс из актуального результата.')}<div class="solver4-charts">${charts}</div></div>`;
  }

  function networkSignature() {
    return JSON.stringify({
      nodes: state.network.nodes.map((node) => [String(node.id), node.type, node.nominalVoltageKV, node.enabled]).sort(),
      branches: state.network.branches.map((branch) => [String(branch.id), String(branch.fromNodeId), String(branch.toNodeId), branch.type]).sort()
    });
  }

  function saveSnapshot(slot) {
    if (!state.result) { showToast('Сначала выполните успешный расчёт.', 'error'); return; }
    state.snapshots[slot] = { name: state.network.name, savedAt: new Date().toISOString(), signature: networkSignature(), result: clone(state.result) };
    writeJson(SNAPSHOTS_KEY, state.snapshots);
    renderComparison();
    showToast(`Результат сохранён как режим ${slot}.`, 'success');
  }

  function renderComparison() {
    const a = state.snapshots.A; const b = state.snapshots.B;
    let comparison = '<div class="solver4-empty"><strong>Сохраните режимы А и Б</strong><span>Структура сети будет проверена по ID узлов и ветвей.</span></div>';
    if (a && b) {
      if (a.signature !== b.signature) comparison = '<div class="solver4-issue"><b>×</b><span>Режимы относятся к сетям с разной структурой. Сравнение заблокировано.</span></div>';
      else {
        const nodeRows = a.result.nodeResults.map((nodeA) => { const nodeB = b.result.nodeResults.find((node) => String(node.id) === String(nodeA.id)); const du = nodeB.voltageKV - nodeA.voltageKV; const da = nodeB.angleDeg - nodeA.angleDeg; return `<tr><td>${esc(nodeA.name || nodeA.id)}</td><td>${fmt(nodeA.voltageKV, 4)}</td><td>${fmt(nodeB.voltageKV, 4)}</td><td class="${du >= 0 ? 'solver4-delta-positive' : 'solver4-delta-negative'}">${fmt(du, 5)}</td><td>${fmt(nodeA.angleDeg, 4)}</td><td>${fmt(nodeB.angleDeg, 4)}</td><td>${fmt(da, 5)}</td></tr>`; }).join('');
        const branchRows = a.result.branchResults.map((branchA) => { const branchB = b.result.branchResults.find((branch) => String(branch.id) === String(branchA.id)); return `<tr><td>${esc(branchA.id)}</td><td>${fmt(branchA.currentA, 3)}</td><td>${fmt(branchB.currentA, 3)}</td><td>${fmt(branchB.currentA - branchA.currentA, 4)}</td><td>${fmt(branchB.activeLossMW - branchA.activeLossMW, 5)}</td><td>${fmt(branchB.reactiveLossMvar - branchA.reactiveLossMvar, 5)}</td><td>${branchA.loadingPercent == null || branchB.loadingPercent == null ? '—' : fmt(branchB.loadingPercent - branchA.loadingPercent, 3)}</td></tr>`; }).join('');
        comparison = `<div class="solver4-charts">${barChart('ΔU узлов', 'кВ: режим Б − режим А', a.result.nodeResults.map((nodeA) => { const nodeB = b.result.nodeResults.find((node) => String(node.id) === String(nodeA.id)); return { label: nodeA.name || nodeA.id, value: nodeB.voltageKV - nodeA.voltageKV }; }))}${barChart('ΔI ветвей', 'А: режим Б − режим А', a.result.branchResults.map((branchA) => { const branchB = b.result.branchResults.find((branch) => String(branch.id) === String(branchA.id)); return { label: branchA.id, value: branchB.currentA - branchA.currentA }; }))}</div><article class="solver4-card"><h3>Узлы</h3><div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Узел</th><th>UA</th><th>UБ</th><th>ΔU</th><th>δA</th><th>δБ</th><th>Δδ</th></tr></thead><tbody>${nodeRows}</tbody></table></div></article><article class="solver4-card"><h3>Ветви</h3><div class="solver4-table-wrap"><table class="solver4-table"><thead><tr><th>Ветвь</th><th>IA</th><th>IБ</th><th>ΔI</th><th>ΔP</th><th>ΔQ</th><th>Δзагрузка, %</th></tr></thead><tbody>${branchRows}</tbody></table></div></article>`;
      }
    }
    const slot = (name, data) => `<article class="solver4-slot"><span>Режим ${name}</span><strong>${esc(data?.name || 'Не сохранён')}</strong><p>${data ? new Date(data.savedAt).toLocaleString('ru-RU') : 'Рассчитайте сеть и сохраните результат.'}</p><button class="secondary-button" data-action="save-snapshot" data-slot="${name}" ${state.result ? '' : 'disabled'}>Сохранить текущий</button></article>`;
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Сравнение режимов', 'Сравниваются только результаты сетей с одинаковыми ID и структурой.')}<div class="solver4-comparison-slots">${slot('A', a)}${slot('B', b)}</div>${comparison}</div>`;
  }

  function renderSettings() {
    const settings = state.network.settings || {};
    viewRoot.innerHTML = `<div class="solver4-view">${viewHeader('Настройки расчёта', 'Параметры Newton–Raphson и базисная мощность проекта.')}
      <article class="solver4-card"><div class="solver4-settings">
        <label><span>Sbase, МВА</span><input data-setting="basePowerMVA" type="number" min="0" step="any" value="${valueOrBlank(state.network.basePowerMVA)}"></label>
        <label><span>Максимум итераций</span><input data-setting="maxIterations" type="number" min="1" step="1" value="${valueOrBlank(settings.maxIterations)}"></label>
        <label><span>Точность, p.u.</span><input data-setting="tolerance" type="number" min="0" step="any" value="${valueOrBlank(settings.tolerance)}"></label>
        <label><span>Порог главного элемента</span><input data-setting="pivotTolerance" type="number" min="0" step="any" value="${valueOrBlank(settings.pivotTolerance)}"></label>
        <label><span>Допуск Q-ограничения, Мвар</span><input data-setting="qLimitToleranceMvar" type="number" min="0" step="any" value="${valueOrBlank(settings.qLimitToleranceMvar)}"></label>
        <div class="solver4-setting-wide solver4-form-note">По умолчанию: tolerance = 1e−8 p.u., maxIterations = 30. Расчёт не изменяет исходные данные проекта.</div>
      </div></article>
    </div>`;
  }

  function renderView() {
    const renderers = {
      overview: renderOverview, nodes: renderNodes, branches: () => renderBranches(), transformers: () => renderBranches((branch) => branch.type === 'transformer'),
      power: renderPower, diagram: renderDiagram, results: renderResults, charts: renderCharts, comparison: renderComparison, settings: renderSettings
    };
    (renderers[state.view] || renderOverview)();
  }

  function setView(view) { state.view = view; renderAll(); }

  function calculate() {
    statusRoot.dataset.kind = 'idle';
    statusRoot.querySelector('strong').textContent = 'Выполняется расчёт…';
    statusRoot.querySelector('span').textContent = 'Диагностика → Ybus → Newton–Raphson';
    window.setTimeout(() => {
      const report = diagnostics();
      state.diagnostics = report;
      state.result = null;
      state.resultStale = false;
      if (!report.ok) { renderAll(); showToast('Расчёт заблокирован ошибками исходных данных.', 'error'); return; }
      const ybus = global.YBus.buildYBus(state.network);
      if (!ybus.ok) { state.diagnostics = ybus.diagnostics; renderAll(); showToast('Не удалось сформировать Ybus.', 'error'); return; }
      const result = global.PowerFlow.calculatePowerFlow(state.network, state.network.settings);
      state.diagnostics = result.diagnostics;
      if (result.converged) {
        state.result = result;
        state.view = 'results';
        showToast(`Режим сошёлся за ${result.iterations} итераций.`, 'success');
      } else showToast(result.diagnostics.messages?.[0] || 'Режим не сошёлся.', 'error');
      renderAll();
    }, 20);
  }

  function openNodeDialog(id = null) {
    nodeForm.reset();
    const node = id == null ? { id: uid('node'), name: '', type: state.network.nodes.some((item) => item.type === 'Slack') ? 'PQ' : 'Slack', nominalVoltageKV: null, voltageSetpointPU: null, angleSetpointDeg: null, loadPMW: null, loadQMvar: null, generationPMW: null, generationQMvar: null, qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true } : nodeById(id);
    document.getElementById('solverNodeDialogTitle').textContent = id == null ? 'Новый узел' : `Узел ${node.name || node.id}`;
    nodeForm.elements.id.value = id == null ? '' : node.id;
    ['nodeId', 'name', 'type', 'nominalVoltageKV', 'voltageSetpointPU', 'angleSetpointDeg', 'loadPMW', 'loadQMvar', 'generationPMW', 'generationQMvar', 'qMinMvar', 'qMaxMvar', 'regionId'].forEach((field) => {
      const key = field === 'nodeId' ? 'id' : field;
      nodeForm.elements[field].value = valueOrBlank(node[key]);
    });
    nodeForm.elements.enabled.checked = node.enabled !== false;
    nodeDialog.showModal();
  }

  function submitNode(event) {
    event.preventDefault();
    const oldId = nodeForm.elements.id.value;
    const node = {
      id: nodeForm.elements.nodeId.value.trim() || null,
      name: nodeForm.elements.name.value.trim() || null,
      type: nodeForm.elements.type.value,
      nominalVoltageKV: nullable(nodeForm.elements.nominalVoltageKV.value),
      voltageSetpointPU: nullable(nodeForm.elements.voltageSetpointPU.value),
      angleSetpointDeg: nullable(nodeForm.elements.angleSetpointDeg.value),
      loadPMW: nullable(nodeForm.elements.loadPMW.value), loadQMvar: nullable(nodeForm.elements.loadQMvar.value),
      generationPMW: nullable(nodeForm.elements.generationPMW.value), generationQMvar: nullable(nodeForm.elements.generationQMvar.value),
      qMinMvar: nullable(nodeForm.elements.qMinMvar.value), qMaxMvar: nullable(nodeForm.elements.qMaxMvar.value),
      regionId: nodeForm.elements.regionId.value.trim() || null, enabled: nodeForm.elements.enabled.checked
    };
    if (!node.id || !node.name) { showToast('ID и название узла обязательны.', 'error'); return; }
    if (state.network.nodes.some((item) => String(item.id) === String(node.id) && String(item.id) !== String(oldId))) { showToast('ID узла должен быть уникальным.', 'error'); return; }
    if (oldId) {
      const index = state.network.nodes.findIndex((item) => String(item.id) === String(oldId));
      state.network.nodes[index] = node;
      if (String(oldId) !== String(node.id)) {
        state.network.branches.forEach((branch) => { if (String(branch.fromNodeId) === String(oldId)) branch.fromNodeId = node.id; if (String(branch.toNodeId) === String(oldId)) branch.toNodeId = node.id; });
        state.layout[node.id] = state.layout[oldId]; delete state.layout[oldId];
      }
    } else state.network.nodes.push(node);
    ensureLayout(); markChanged(); nodeDialog.close(); renderAll();
  }

  function openBranchDialog(id = null, type = 'line') {
    if (state.network.nodes.length < 2) { showToast('Сначала добавьте минимум два узла.', 'error'); return; }
    branchForm.reset();
    const branch = id == null ? { id: uid(type === 'transformer' ? 'transformer' : 'line'), name: '', fromNodeId: state.network.nodes[0].id, toNodeId: state.network.nodes[1].id, type, resistanceOhm: null, reactanceOhm: null, chargingSusceptanceMicroS: 0, tapRatio: 1, phaseShiftDeg: 0, ratedCurrentA: null, ratedCurrentFromA: null, ratedCurrentToA: null, enabled: true } : state.network.branches.find((item) => String(item.id) === String(id));
    const options = state.network.nodes.map((node) => `<option value="${esc(node.id)}">${esc(node.name || node.id)} · ${fmt(node.nominalVoltageKV, 2)} кВ</option>`).join('');
    branchForm.elements.fromNodeId.innerHTML = options; branchForm.elements.toNodeId.innerHTML = options;
    document.getElementById('solverBranchDialogTitle').textContent = id == null ? (type === 'transformer' ? 'Новый трансформатор' : 'Новая ветвь') : `Ветвь ${branch.name || branch.id}`;
    branchForm.elements.id.value = id == null ? '' : branch.id;
    ['branchId', 'name', 'fromNodeId', 'toNodeId', 'type', 'resistanceOhm', 'reactanceOhm', 'chargingSusceptanceMicroS', 'tapRatio', 'phaseShiftDeg', 'ratedCurrentA', 'ratedCurrentFromA', 'ratedCurrentToA'].forEach((field) => {
      const key = field === 'branchId' ? 'id' : field;
      branchForm.elements[field].value = valueOrBlank(branch[key]);
    });
    branchForm.elements.enabled.checked = branch.enabled !== false;
    branchDialog.showModal();
  }

  function submitBranch(event) {
    event.preventDefault();
    const oldId = branchForm.elements.id.value;
    const branch = {
      id: branchForm.elements.branchId.value.trim() || null, name: branchForm.elements.name.value.trim() || null,
      fromNodeId: branchForm.elements.fromNodeId.value, toNodeId: branchForm.elements.toNodeId.value, type: branchForm.elements.type.value,
      resistanceOhm: nullable(branchForm.elements.resistanceOhm.value), reactanceOhm: nullable(branchForm.elements.reactanceOhm.value), chargingSusceptanceMicroS: nullable(branchForm.elements.chargingSusceptanceMicroS.value),
      tapRatio: nullable(branchForm.elements.tapRatio.value), phaseShiftDeg: nullable(branchForm.elements.phaseShiftDeg.value), ratedCurrentA: nullable(branchForm.elements.ratedCurrentA.value),
      ratedCurrentFromA: nullable(branchForm.elements.ratedCurrentFromA.value), ratedCurrentToA: nullable(branchForm.elements.ratedCurrentToA.value), enabled: branchForm.elements.enabled.checked
    };
    if (!branch.id) { showToast('ID ветви обязателен.', 'error'); return; }
    if (state.network.branches.some((item) => String(item.id) === String(branch.id) && String(item.id) !== String(oldId))) { showToast('ID ветви должен быть уникальным.', 'error'); return; }
    if (oldId) state.network.branches[state.network.branches.findIndex((item) => String(item.id) === String(oldId))] = branch;
    else state.network.branches.push(branch);
    markChanged(); branchDialog.close(); renderAll();
  }

  function projectRecords() { const records = readJson(PROJECTS_KEY, []); return Array.isArray(records) ? records : []; }
  function renderProjectSelect() {
    const records = projectRecords();
    const legacyRastr = readJson('smartEnergySettings', {})?.rastrMode;
    projectSelect.innerHTML = `<option value="">Не выбрано</option>${legacyRastr ? `<option value="__rastr__">Rastr Mode · совместимое сохранение</option>` : ''}${records.map((project) => `<option value="${esc(project.id)}" ${project.id === state.projectId ? 'selected' : ''}>${esc(project.name)} · ${new Date(project.updatedAt).toLocaleDateString('ru-RU')}</option>`).join('')}`;
  }

  function saveProject(copyMode = false) {
    const records = projectRecords();
    let id = copyMode || !state.projectId ? uid('project') : state.projectId;
    const existingIndex = records.findIndex((project) => project.id === id);
    if (existingIndex >= 0 && !global.confirm(`Перезаписать проект «${records[existingIndex].name}»?`)) return;
    const name = state.network.name || 'Без названия';
    const record = { schemaVersion: 4, id, name: copyMode ? `${name} — копия` : name, network: clone(state.network), layout: clone(state.layout), updatedAt: new Date().toISOString() };
    if (copyMode) { record.network.name = record.name; state.network.name = record.name; projectNameInput.value = record.name; }
    if (existingIndex >= 0) records[existingIndex] = record; else records.push(record);
    if (!writeJson(PROJECTS_KEY, records)) { showToast('localStorage недоступен: проект не сохранён.', 'error'); return; }
    state.projectId = id; state.dirty = false; renderAll(); showToast(copyMode ? 'Копия проекта сохранена.' : 'Проект сохранён.', 'success');
  }

  function openProject() {
    const id = projectSelect.value;
    if (!id) { showToast('Выберите сохранённый проект.', 'error'); return; }
    if (state.dirty && !global.confirm('Несохранённые изменения будут потеряны. Открыть другой проект?')) return;
    if (id === '__rastr__') {
      const rastr = readJson('smartEnergySettings', {})?.rastrMode;
      if (!rastr) { showToast('Сохранение Rastr Mode не найдено.', 'error'); return; }
      const rastrLayout = Object.fromEntries((rastr.nodes || []).filter((node) => Number.isFinite(node.x) && Number.isFinite(node.y)).map((node) => [node.id, { x: node.x, y: node.y }]));
      setProject({ ...rastr, baseMVA: rastr.baseMVA ?? 100 }, rastrLayout, null);
      state.dirty = true; renderStatus(); showToast('Сохранение Rastr Mode открыто через адаптер. Сохраните как новый проект.', 'success'); return;
    }
    const project = projectRecords().find((item) => item.id === id);
    if (!project) { showToast('Проект не найден.', 'error'); return; }
    setProject(project.network, project.layout, project.id);
  }

  function download(name, content, type) {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([content], { type })); link.download = name; link.click();
    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  function exportJson() {
    const payload = { schemaVersion: 4, exportedAt: new Date().toISOString(), network: state.network, layout: state.layout };
    download(`${(state.network.name || 'smart-solver').replace(/[^\p{L}\p{N}-]+/gu, '_')}.json`, JSON.stringify(payload, null, 2), 'application/json');
  }

  function importJson(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const payload = JSON.parse(reader.result);
        const source = payload.network || payload;
        if (source.schemaVersion === 2 && source.basePowerMVA == null && source.baseMVA == null) source.baseMVA = 100;
        setProject(source, payload.layout || source.layout || {}, null);
        state.dirty = true; renderStatus(); showToast('Проект импортирован. Сохранение ещё не выполнено.', 'success');
      } catch (error) { showToast(`Ошибка импорта: ${error.message}`, 'error'); }
      importInput.value = '';
    };
    reader.readAsText(file);
  }

  function exportCsv() {
    if (!state.result) { showToast('Нет результатов для экспорта.', 'error'); return; }
    const lines = ['Тип;ID;U_kV;U_pu;Angle_deg;Pload_MW;Qload_Mvar;Pgen_MW;Qgen_Mvar'];
    state.result.nodeResults.forEach((node) => lines.push(['NODE', node.id, node.voltageKV, node.voltagePU, node.angleDeg, node.loadPMW, node.loadQMvar, node.generationPMW, node.generationQMvar].join(';')));
    lines.push('', 'Тип;ID;From;To;Pij_MW;Qij_Mvar;Pji_MW;Qji_Mvar;Iij_A;Iji_A;LossP_MW;LossQ_Mvar;Loading_percent');
    state.result.branchResults.forEach((branch) => lines.push(['BRANCH', branch.id, branch.fromNodeId, branch.toNodeId, branch.pijMW, branch.qijMvar, branch.pjiMW, branch.qjiMvar, branch.currentFromA, branch.currentToA, branch.activeLossMW, branch.reactiveLossMvar, branch.loadingPercent ?? ''].join(';')));
    download(`${(state.network.name || 'smart-solver').replace(/[^\p{L}\p{N}-]+/gu, '_')}_results.csv`, `\uFEFF${lines.join('\n')}`, 'text/csv;charset=utf-8');
  }

  function bindDiagramInteractions() {
    const svg = document.getElementById('solverDiagramSvg'); if (!svg) return;
    const world = document.getElementById('solverDiagramWorld');
    let interaction = null;
    svg.addEventListener('pointerdown', (event) => {
      const node = event.target.closest('[data-node-id]');
      interaction = { type: node ? 'node' : 'pan', nodeId: node?.dataset.nodeId, x: event.clientX, y: event.clientY, base: node ? { ...state.layout[node.dataset.nodeId] } : { x: state.diagram.panX, y: state.diagram.panY }, element: node };
      svg.setPointerCapture(event.pointerId);
    });
    svg.addEventListener('pointermove', (event) => {
      if (!interaction) return;
      const dx = event.clientX - interaction.x; const dy = event.clientY - interaction.y;
      if (interaction.type === 'node') {
        const point = { x: interaction.base.x + dx / state.diagram.zoom, y: interaction.base.y + dy / state.diagram.zoom };
        state.layout[interaction.nodeId] = point; interaction.element.setAttribute('transform', `translate(${point.x} ${point.y})`);
      } else {
        state.diagram.panX = interaction.base.x + dx; state.diagram.panY = interaction.base.y + dy;
        world.setAttribute('transform', `translate(${state.diagram.panX} ${state.diagram.panY}) scale(${state.diagram.zoom})`);
      }
    });
    const finish = () => {
      if (!interaction) return;
      state.dirty = true;
      interaction = null;
      renderStatus();
      renderDiagram();
    };
    svg.addEventListener('pointerup', finish); svg.addEventListener('pointercancel', finish);
    svg.addEventListener('wheel', (event) => { event.preventDefault(); state.diagram.zoom = Math.min(2.5, Math.max(.35, state.diagram.zoom * (event.deltaY < 0 ? 1.12 : .89))); world.setAttribute('transform', `translate(${state.diagram.panX} ${state.diagram.panY}) scale(${state.diagram.zoom})`); }, { passive: false });
  }

  function handleAction(button) {
    const action = button.dataset.action;
    if (action === 'calculate') calculate();
    else if (action === 'validate') { state.diagnostics = diagnostics(); renderAll(); showToast(state.diagnostics.ok ? 'Исходные данные корректны.' : `Обнаружено ошибок: ${state.diagnostics.errors.length}.`, state.diagnostics.ok ? 'success' : 'error'); }
    else if (action === 'load-example') { if (!state.dirty || global.confirm('Заменить текущие несохранённые данные примером 220 кВ?')) { setProject(exampleNetwork()); state.dirty = true; renderStatus(); } }
    else if (action === 'new-project') { if (!state.dirty || global.confirm('Создать новый проект и потерять несохранённые изменения?')) setProject(blankNetwork()); }
    else if (action === 'save-project') saveProject(false);
    else if (action === 'copy-project') saveProject(true);
    else if (action === 'open-project') openProject();
    else if (action === 'export-json') exportJson();
    else if (action === 'import-json') importInput.click();
    else if (action === 'export-csv') exportCsv();
    else if (action === 'add-node') openNodeDialog();
    else if (action === 'edit-node') openNodeDialog(button.dataset.id);
    else if (action === 'delete-node') {
      const id = button.dataset.id; const linked = state.network.branches.filter((branch) => String(branch.fromNodeId) === String(id) || String(branch.toNodeId) === String(id));
      if (global.confirm(`Удалить узел и ${linked.length} связанных ветвей?`)) { state.network.nodes = state.network.nodes.filter((node) => String(node.id) !== String(id)); state.network.branches = state.network.branches.filter((branch) => String(branch.fromNodeId) !== String(id) && String(branch.toNodeId) !== String(id)); delete state.layout[id]; markChanged(); renderAll(); }
    }
    else if (action === 'add-branch') openBranchDialog(null, button.dataset.type || 'line');
    else if (action === 'edit-branch') openBranchDialog(button.dataset.id);
    else if (action === 'delete-branch') { if (global.confirm('Удалить ветвь?')) { state.network.branches = state.network.branches.filter((branch) => String(branch.id) !== String(button.dataset.id)); markChanged(); renderAll(); } }
    else if (action === 'toggle-branch') { const branch = state.network.branches.find((item) => String(item.id) === String(button.dataset.id)); branch.enabled = !branch.enabled; markChanged(); renderAll(); }
    else if (action === 'close-node-dialog') nodeDialog.close();
    else if (action === 'close-branch-dialog') branchDialog.close();
    else if (action === 'diagram-mode') { state.diagram.mode = button.dataset.mode; renderDiagram(); }
    else if (action === 'diagram-zoom-in') { state.diagram.zoom = Math.min(2.5, state.diagram.zoom * 1.2); renderDiagram(); }
    else if (action === 'diagram-zoom-out') { state.diagram.zoom = Math.max(.35, state.diagram.zoom / 1.2); renderDiagram(); }
    else if (action === 'diagram-fit') { state.diagram.zoom = 1; state.diagram.panX = 0; state.diagram.panY = 0; renderDiagram(); }
    else if (action === 'diagram-auto') { ensureLayout(true); state.dirty = true; renderDiagram(); renderStatus(); }
    else if (action === 'save-snapshot') saveSnapshot(button.dataset.slot);
  }

  root.addEventListener('click', (event) => {
    const viewButton = event.target.closest('[data-view]'); if (viewButton) { setView(viewButton.dataset.view); return; }
    const actionButton = event.target.closest('[data-action]'); if (actionButton) handleAction(actionButton);
  });
  document.addEventListener('click', (event) => { const button = event.target.closest('[data-action]'); if (button && !root.contains(button)) handleAction(button); });
  viewRoot.addEventListener('change', (event) => {
    if (event.target.matches('[data-visibility]')) { state.diagram.visibility[event.target.dataset.visibility] = event.target.checked; renderDiagram(); return; }
    if (event.target.matches('[data-setting]')) {
      const key = event.target.dataset.setting; const value = nullable(event.target.value);
      if (key === 'basePowerMVA') state.network.basePowerMVA = value; else state.network.settings[key] = value;
      markChanged();
    }
  });
  projectNameInput.addEventListener('input', () => { state.network.name = projectNameInput.value.trim() || null; state.dirty = true; renderStatus(); });
  nodeForm.addEventListener('submit', submitNode);
  branchForm.addEventListener('submit', submitBranch);
  importInput.addEventListener('change', () => { if (importInput.files[0]) importJson(importInput.files[0]); });
  global.addEventListener('beforeunload', (event) => { if (state.dirty) { event.preventDefault(); event.returnValue = ''; } });

  setProject(exampleNetwork(), { 'bus-1': { x: 230, y: 290 }, 'bus-2': { x: 760, y: 290 } });
})(window);
