/** MATPOWER case9 converted to Smart Solver physical branch units. */
'use strict';

const basePowerMVA = 100;
const baseVoltageKV = 345;
const impedanceBaseOhm = baseVoltageKV ** 2 / basePowerMVA;

function node(id, type, values = {}) {
  return Object.freeze({
    id: String(id), name: `Bus ${id}`, type, nominalVoltageKV: baseVoltageKV,
    voltageSetpointPU: type === 'Slack' || type === 'PV' ? values.voltage : null,
    angleSetpointDeg: type === 'Slack' ? 0 : null,
    loadPMW: values.loadP || 0, loadQMvar: values.loadQ || 0,
    generationPMW: values.generationP ?? 0, generationQMvar: values.generationQ ?? 0,
    qMinMvar: values.qMin ?? null, qMaxMvar: values.qMax ?? null,
    regionId: null, enabled: true
  });
}

function branch(id, fromNodeId, toNodeId, resistancePU, reactancePU, susceptancePU) {
  return Object.freeze({
    id, name: `Branch ${fromNodeId}-${toNodeId}`, fromNodeId: String(fromNodeId), toNodeId: String(toNodeId), type: 'line',
    resistanceOhm: resistancePU * impedanceBaseOhm,
    reactanceOhm: reactancePU * impedanceBaseOhm,
    chargingSusceptanceMicroS: susceptancePU / impedanceBaseOhm * 1e6,
    tapRatio: 1, phaseShiftDeg: 0,
    ratedCurrentA: null, ratedCurrentFromA: null, ratedCurrentToA: null, enabled: true
  });
}

const matpowerCase9 = Object.freeze({
  schemaVersion: 'smart-solver-network/1',
  name: 'MATPOWER Case 9',
  basePowerMVA,
  nodes: Object.freeze([
    node(1, 'Slack', { voltage: 1.04, generationP: null, generationQ: null }),
    node(2, 'PV', { voltage: 1.025, generationP: 163, qMin: -300, qMax: 300 }),
    node(3, 'PV', { voltage: 1.025, generationP: 85, qMin: -300, qMax: 300 }),
    node(4, 'PQ'),
    node(5, 'PQ', { loadP: 90, loadQ: 30 }),
    node(6, 'PQ'),
    node(7, 'PQ', { loadP: 100, loadQ: 35 }),
    node(8, 'PQ'),
    node(9, 'PQ', { loadP: 125, loadQ: 50 })
  ]),
  branches: Object.freeze([
    branch('1-4', 1, 4, 0, 0.0576, 0),
    branch('4-5', 4, 5, 0.017, 0.092, 0.158),
    branch('5-6', 5, 6, 0.039, 0.17, 0.358),
    branch('3-6', 3, 6, 0, 0.0586, 0),
    branch('6-7', 6, 7, 0.0119, 0.1008, 0.209),
    branch('7-8', 7, 8, 0.0085, 0.072, 0.149),
    branch('8-2', 8, 2, 0, 0.0625, 0),
    branch('8-9', 8, 9, 0.032, 0.161, 0.306),
    branch('9-4', 9, 4, 0.01, 0.085, 0.176)
  ]),
  settings: Object.freeze({ tolerance: 1e-10, maxIterations: 30 })
});

module.exports = Object.freeze({ matpowerCase9, impedanceBaseOhm });
