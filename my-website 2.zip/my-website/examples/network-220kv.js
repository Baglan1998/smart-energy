/**
 * Двухузловой эталон этапа 2.
 *
 * Конец технического задания оборван после «АС-240/32 —», поэтому R/X/B
 * здесь заданы явными тестовыми допущениями, а не выводятся из марки.
 */
'use strict';

const lineAssumptions = Object.freeze({
  conductor: 'АС-240/32',
  lengthKM: 100,
  resistanceOhmPerKM: 0.118,
  reactanceOhmPerKM: 0.405,
  chargingSusceptanceMicroSPerKM: 2.8
});

const network220KV = Object.freeze({
  schemaVersion: 'smart-solver-network/1',
  name: 'Эталон 220 кВ: 80 + j30 МВА',
  basePowerMVA: 100,
  nodes: Object.freeze([
    Object.freeze({
      id: 'bus-1', name: 'Узел 1 — Slack', type: 'Slack', nominalVoltageKV: 220,
      voltageSetpointPU: 1, angleSetpointDeg: 0,
      loadPMW: 0, loadQMvar: 0, generationPMW: null, generationQMvar: null,
      qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true
    }),
    Object.freeze({
      id: 'bus-2', name: 'Узел 2 — нагрузка', type: 'PQ', nominalVoltageKV: 220,
      voltageSetpointPU: null, angleSetpointDeg: null,
      loadPMW: 80, loadQMvar: 30, generationPMW: 0, generationQMvar: 0,
      qMinMvar: null, qMaxMvar: null, regionId: null, enabled: true
    })
  ]),
  branches: Object.freeze([
    Object.freeze({
      id: 'line-1-2', name: 'ВЛ 1–2, АС-240/32', fromNodeId: 'bus-1', toNodeId: 'bus-2', type: 'line',
      resistanceOhm: lineAssumptions.resistanceOhmPerKM * lineAssumptions.lengthKM,
      reactanceOhm: lineAssumptions.reactanceOhmPerKM * lineAssumptions.lengthKM,
      chargingSusceptanceMicroS: lineAssumptions.chargingSusceptanceMicroSPerKM * lineAssumptions.lengthKM,
      tapRatio: 1, phaseShiftDeg: 0, ratedCurrentA: null, enabled: true
    })
  ]),
  settings: Object.freeze({ tolerance: 1e-8, maxIterations: 30 })
});

module.exports = Object.freeze({ lineAssumptions, network220KV });
